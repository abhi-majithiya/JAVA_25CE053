import java.util.Objects;

class Customer implements Cloneable {
    private static long customerCounter = 200;
    private final String customerId;
    private String name;
    private String email;
    private Address residentAddress;

    public static class Address {
        private String line;
        private String city;
        private String pincode;

        public Address(String line, String city, String pincode) {
            this.line = line;
            this.city = city;
            this.pincode = pincode;
        }

        public String getLine() {
            return line;
        }

        public String getCity() {
            return city;
        }

        public String getPincode() {
            return pincode;
        }

        @Override
        public String toString() {
            return line + ", " + city + " - " + pincode;
        }
    }

    public Customer(String name, String email, Address residentAddress) {
        customerCounter++;
        this.customerId = "CUST" + customerCounter;
        this.name = name;
        this.email = email;
        this.residentAddress = residentAddress;
    }

    private Customer(String customerId, String name, String email, Address residentAddress) {
        this.customerId = customerId;
        this.name = name;
        this.email = email;
        this.residentAddress = residentAddress;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public Address getAddress() {
        return residentAddress;
    }

    public void setAddress(Address residentAddress) {
        this.residentAddress = residentAddress;
    }

    @Override
    public Customer clone() {
        try {
            Customer clonedCustomer = (Customer) super.clone();
            if (this.residentAddress != null) {
                clonedCustomer.residentAddress = new Address(
                    this.residentAddress.getLine(),
                    this.residentAddress.getCity(),
                    this.residentAddress.getPincode()
                );
            }
            return clonedCustomer;
        } catch (CloneNotSupportedException exception) {
            return new Customer(this.customerId, this.name, this.email, new Address(
                this.residentAddress.getLine(),
                this.residentAddress.getCity(),
                this.residentAddress.getPincode()
            ));
        }
    }

    @Override
    public String toString() {
        return "Customer[" + customerId + ", " + name + ", " + email + ", Address: " + residentAddress + "]";
    }
}

class Account {
    private final String accountNumber;
    private String ownerName;
    private long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public long getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        return "Account{" + "accountNumber='" + accountNumber + '\'' + ", ownerName='" + ownerName + '\'' + ", balance=Rs. " + balance + '}';
    }

    @Override
    public boolean equals(Object otherObject) {
        if (this == otherObject) return true;
        if (otherObject == null || getClass() != otherObject.getClass()) return false;
        Account otherAccount = (Account) otherObject;
        return Objects.equals(accountNumber, otherAccount.accountNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountNumber);
    }
}

public class Practical03_ObjectContract {
    public static void main(String[] args) {
        Customer.Address primaryAddress = new Customer.Address("12 Anand Flat, Station Road", "Anand", "388001");
        Customer firstCustomer = new Customer("Pooja Shah", "pooja.shah@email.com", primaryAddress);
        Customer duplicatedCustomer = firstCustomer.clone();

        System.out.println("Original Customer: " + firstCustomer);
        System.out.println("Cloned Customer:   " + duplicatedCustomer);

        Account accountAlpha = new Account("AC1001", "Pooja Shah", 18500);
        Account accountBeta = new Account("AC1001", "Pooja Shah (Joint)", 22000);
        Account accountGamma = new Account("AC1002", "Vikram Rathod", 35000);

        System.out.println("\n--- Account toString() Output ---");
        System.out.println("Alpha: " + accountAlpha);
        System.out.println("Beta:  " + accountBeta);
        System.out.println("Gamma: " + accountGamma);

        System.out.println("\n--- Testing equals() and hashCode() ---");
        boolean alphaEqualsBeta = accountAlpha.equals(accountBeta);
        boolean alphaEqualsGamma = accountAlpha.equals(accountGamma);
        System.out.println("accountAlpha.equals(accountBeta)  : " + alphaEqualsBeta + " (Same Account Number)");
        System.out.println("accountAlpha.equals(accountGamma) : " + alphaEqualsGamma + " (Different Account Numbers)");
        System.out.println("accountAlpha hashCode: " + accountAlpha.hashCode());
        System.out.println("accountBeta  hashCode: " + accountBeta.hashCode());
        System.out.println("accountGamma hashCode: " + accountGamma.hashCode());

        System.out.println("\n--- Testing instanceof Type Verification ---");
        Object testReference = accountAlpha;
        if (testReference instanceof Account parsedAccount) {
            System.out.println("testReference is an instance of Account for: " + parsedAccount.getOwnerName());
        }
        if (firstCustomer instanceof Cloneable) {
            System.out.println("firstCustomer successfully implements Cloneable interface.");
        }
    }
}