import java.util.Scanner;

record BankInfo(String name, String branch) {}

enum MenuOption {
    OPEN_ACCOUNT,
    DEPOSIT,
    WITHDRAW,
    TRANSFER,
    EXIT
}

public class Practical01_MiniBank {
    public static void main(String[] args) {
        BankInfo bankHeader = new BankInfo("CHARUSAT Apex Bank", "Changa Branch");
        System.out.println("=================================================");
        System.out.println("         " + bankHeader.name() + " - " + bankHeader.branch());
        System.out.println("=================================================");

        Scanner consoleScanner = new Scanner("1\n2\n3\n4\n5\n");
        boolean keepRunning = true;

        while (keepRunning) {
            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1. Open Account");
            System.out.println("2. Deposit Funds");
            System.out.println("3. Withdraw Funds");
            System.out.println("4. Transfer Funds");
            System.out.println("5. Exit System");
            System.out.print("Enter your option [1-5]: ");

            if (!consoleScanner.hasNextInt()) {
                break;
            }

            int selectedOption = consoleScanner.nextInt();
            System.out.println(selectedOption);

            String statusMessage = switch (selectedOption) {
                case 1 -> "Action: Open Account - will be initialized in Practical 2.";
                case 2 -> "Action: Deposit Funds - to be implemented in a later lab.";
                case 3 -> "Action: Withdraw Funds - to be implemented in a later lab.";
                case 4 -> "Action: Transfer Funds - to be implemented in a later lab.";
                case 5 -> {
                    keepRunning = false;
                    yield "Exiting MiniBank application. Thank you for banking with us!";
                }
                default -> "Invalid option selected. Please choose between 1 and 5.";
            };

            System.out.println(statusMessage);
        }
        consoleScanner.close();
    }
}