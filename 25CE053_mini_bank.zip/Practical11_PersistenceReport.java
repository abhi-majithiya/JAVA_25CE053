import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;

class Customer implements Serializable {
    private static final long serialVersionUID = 1101L;
    private final String customerId;
    private final String name;

    public Customer(String customerId, String name) {
        this.customerId = customerId;
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

class Account implements Serializable {
    private static final long serialVersionUID = 1102L;
    private final String accountNumber;
    private final String ownerName;
    private long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public long getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        return accountNumber + " | " + ownerName + " | Balance: Rs. " + balance;
    }
}

class StatePersister {
    public static void save(Account[] accounts, Path targetFilePath) throws IOException {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(Files.newOutputStream(targetFilePath))) {
            outputStream.writeObject(accounts);
        }
    }

    public static Account[] load(Path sourceFilePath) throws IOException, ClassNotFoundException {
        try (ObjectInputStream inputStream = new ObjectInputStream(Files.newInputStream(sourceFilePath))) {
            return (Account[]) inputStream.readObject();
        }
    }
}

class TransactionLog {
    public static void append(Path logFilePath, String logEntry) throws IOException {
        String formattedEntry = logEntry + System.lineSeparator();
        Files.write(logFilePath, formattedEntry.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }
}

class ReportGenerator {
    public static String generateDailyReport(Path logsDirectory, Path reportOutputPath) throws IOException {
        long totalDeposits = 0;
        long totalWithdrawals = 0;
        int transactionCount = 0;

        StringBuilder reportBuilder = new StringBuilder();
        reportBuilder.append("=========================================\n");
        reportBuilder.append("         END-OF-DAY AUDIT REPORT         \n");
        reportBuilder.append("=========================================\n");

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(logsDirectory, "*.log")) {
            for (Path logFile : stream) {
                BasicFileAttributes attributes = Files.readAttributes(logFile, BasicFileAttributes.class);
                reportBuilder.append("Log File      : ").append(logFile.getFileName()).append("\n");
                reportBuilder.append("File Size     : ").append(attributes.size()).append(" bytes\n");
                reportBuilder.append("Last Modified : ").append(attributes.lastModifiedTime()).append("\n");

                try (BufferedReader reader = Files.newBufferedReader(logFile)) {
                    String currentLine;
                    while ((currentLine = reader.readLine()) != null) {
                        String[] segments = currentLine.split(",");
                        if (segments.length >= 3) {
                            String action = segments[0].trim();
                            long amount = Long.parseLong(segments[2].trim());
                            if ("DEPOSIT".equalsIgnoreCase(action)) {
                                totalDeposits += amount;
                                transactionCount++;
                            } else if ("WITHDRAW".equalsIgnoreCase(action)) {
                                totalWithdrawals += amount;
                                transactionCount++;
                            }
                        }
                    }
                }
            }
        }

        reportBuilder.append("-----------------------------------------\n");
        reportBuilder.append("Total Processed Transactions : ").append(transactionCount).append("\n");
        reportBuilder.append("Total Aggregated Deposits    : Rs. ").append(totalDeposits).append("\n");
        reportBuilder.append("Total Aggregated Withdrawals : Rs. ").append(totalWithdrawals).append("\n");
        reportBuilder.append("Net Vault Position Delta     : Rs. ").append(totalDeposits - totalWithdrawals).append("\n");
        reportBuilder.append("=========================================\n");

        String finalizedReport = reportBuilder.toString();
        Files.writeString(reportOutputPath, finalizedReport, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        return finalizedReport;
    }
}

public class Practical11_PersistenceReport {
    public static void main(String[] args) throws Exception {
        Path workingDir = Paths.get("target_store");
        Files.createDirectories(workingDir);
        Path serializedStore = workingDir.resolve("accounts_data.ser");
        Path logFilePath = workingDir.resolve("daily_transactions.log");
        Path reportFilePath = workingDir.resolve("audit_summary.txt");

        Account[] originalAccounts = new Account[] {
            new Account("AC101", "Tanvi Dave", 45000),
            new Account("AC102", "Hardik Patel", 62000),
            new Account("AC103", "Bhavna Shah", 18500)
        };

        System.out.println("--- 1. Serializing Accounts to File ---");
        StatePersister.save(originalAccounts, serializedStore);
        System.out.println("Accounts serialized to: " + serializedStore.toAbsolutePath());

        System.out.println("\n--- 2. Deserializing Accounts from File ---");
        Account[] loadedAccounts = StatePersister.load(serializedStore);
        for (Account acc : loadedAccounts) {
            System.out.println("Loaded Account: " + acc);
        }

        System.out.println("\n--- 3. Writing Append-Only Transaction Log Entries ---");
        TransactionLog.append(logFilePath, "DEPOSIT,AC101,10000");
        TransactionLog.append(logFilePath, "WITHDRAW,AC102,5000");
        TransactionLog.append(logFilePath, "DEPOSIT,AC103,15000");
        TransactionLog.append(logFilePath, "WITHDRAW,AC101,2000");
        System.out.println("4 log records written to " + logFilePath.getFileName());

        System.out.println("\n--- 4. Generating End-of-Day Audit Report via NIO ---");
        String generatedReport = ReportGenerator.generateDailyReport(workingDir, reportFilePath);
        System.out.println(generatedReport);
    }
}