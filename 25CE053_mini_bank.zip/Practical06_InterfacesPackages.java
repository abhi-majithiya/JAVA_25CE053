import static java.lang.Math.round;

interface Transactable {
    void deposit(long amount);
    boolean withdraw(long amount);
}

interface InterestBearing {
    double interestRate();
    long getBalance();

    default double yearlyInterest() {
        return (getBalance() * interestRate()) / 100.0;
    }
}

@FunctionalInterface
interface WithdrawRule {
    boolean allow(Account account, long amount);
}

interface Premium {}

abstract class Account implements Transactable, InterestBearing {
    private final String accountNumber;
    private final String ownerName;
    protected long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    @Override
    public void deposit(long amount) {
        if (amount > 0) {
            balance += amount;
        }
    }

    @Override
    public boolean withdraw(long amount) {
        if (amount > 0 && canWithdraw(amount)) {
            balance -= amount;
            return true;
        }
        return false;
    }

    public abstract boolean canWithdraw(long amount);

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    @Override
    public long getBalance() {
        return balance;
    }
}

class SavingsAccount extends Account implements Premium {
    private final long minBalance;

    public SavingsAccount(String accountNumber, String ownerName, long balance, long minBalance) {
        super(accountNumber, ownerName, balance);
        this.minBalance = minBalance;
    }

    @Override
    public double interestRate() {
        return 4.5;
    }

    @Override
    public boolean canWithdraw(long amount) {
        return (balance - amount) >= minBalance;
    }
}

public class Practical06_InterfacesPackages {
    public static void main(String[] args) {
        SavingsAccount premiumCustomerAccount = new SavingsAccount("SB501", "Rhea Sengupta", 50000, 5000);

        System.out.println("--- Interface Capabilities Verification ---");
        System.out.println("Account Number : " + premiumCustomerAccount.getAccountNumber());
        System.out.println("Owner Name     : " + premiumCustomerAccount.getOwnerName());
        System.out.println("Active Balance : Rs. " + premiumCustomerAccount.getBalance());
        System.out.println("Interest Rate  : " + premiumCustomerAccount.interestRate() + "%");

        double computedInterest = premiumCustomerAccount.yearlyInterest();
        long roundedInterest = round(computedInterest);
        System.out.println("Yearly Default Interest : Rs. " + computedInterest + " (Rounded: Rs. " + roundedInterest + ")");

        if (premiumCustomerAccount instanceof Premium) {
            System.out.println("Marker Interface Check  : Account qualifies for Premium banking privileges.");
        }

        System.out.println("\n--- Functional Interface WithdrawRule ---");
        WithdrawRule anonymousRule = new WithdrawRule() {
            @Override
            public boolean allow(Account account, long amount) {
                return amount <= 20000 && account.canWithdraw(amount);
            }
        };

        WithdrawRule lambdaRule = (account, amount) -> amount <= 25000 && account.canWithdraw(amount);

        long withdrawalAttemptOne = 18000;
        long withdrawalAttemptTwo = 22000;

        System.out.println("Anonymous Class Rule for Rs. " + withdrawalAttemptOne + " : " + anonymousRule.allow(premiumCustomerAccount, withdrawalAttemptOne));
        System.out.println("Anonymous Class Rule for Rs. " + withdrawalAttemptTwo + " : " + anonymousRule.allow(premiumCustomerAccount, withdrawalAttemptTwo));
        System.out.println("Lambda Expression Rule for Rs. " + withdrawalAttemptTwo + " : " + lambdaRule.allow(premiumCustomerAccount, withdrawalAttemptTwo));
    }
}