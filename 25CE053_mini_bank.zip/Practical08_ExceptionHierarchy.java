class BankException extends Exception {
    public BankException(String message) {
        super(message);
    }
}

class InsufficientFundsException extends BankException {
    private final long shortfall;

    public InsufficientFundsException(String message, long shortfall) {
        super(message);
        this.shortfall = shortfall;
    }

    public long getShortfall() {
        return shortfall;
    }
}

class AccountNotFoundException extends BankException {
    public AccountNotFoundException(String message) {
        super(message);
    }
}

class InvalidAmountException extends BankException {
    public InvalidAmountException(String message) {
        super(message);
    }
}

class AuditSession implements AutoCloseable {
    private final String sessionIdentifier;

    public AuditSession(String sessionIdentifier) {
        this.sessionIdentifier = sessionIdentifier;
        System.out.println("[AuditSession] Log session '" + sessionIdentifier + "' opened.");
    }

    @Override
    public void close() {
        System.out.println("[AuditSession] Log session '" + sessionIdentifier + "' closed successfully.");
    }
}

class Account {
    private final String accountNumber;
    private final String ownerName;
    private long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public void deposit(long amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Deposit amount must be positive. Received: " + amount);
        }
        balance += amount;
        System.out.println("Deposit of Rs. " + amount + " successful on " + accountNumber + ". New balance: Rs. " + balance);
    }

    public void withdraw(long amount) throws InsufficientFundsException, InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal amount must be greater than zero. Received: " + amount);
        }
        if (amount > balance) {
            long requiredShortfall = amount - balance;
            throw new InsufficientFundsException("Insufficient balance on " + accountNumber + ". Available: Rs. " + balance + ", Requested: Rs. " + amount, requiredShortfall);
        }
        balance -= amount;
        System.out.println("Withdrawal of Rs. " + amount + " successful on " + accountNumber + ". Remaining balance: Rs. " + balance);
    }

    public void transfer(Account targetAccount, long amount) throws BankException {
        if (targetAccount == null) {
            throw new AccountNotFoundException("Target beneficiary account cannot be null.");
        }
        System.out.println("Initiating transfer of Rs. " + amount + " from " + accountNumber + " to " + targetAccount.getAccountNumber());
        try {
            this.withdraw(amount);
            targetAccount.deposit(amount);
            System.out.println("Transfer completed successfully.");
        } catch (BankException bankingError) {
            System.out.println("Transfer aborted due to: " + bankingError.getMessage());
            throw bankingError;
        } finally {
            System.out.println("Transfer transaction sequence completed for " + accountNumber);
        }
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public long getBalance() {
        return balance;
    }
}

public class Practical08_ExceptionHierarchy {
    public static void main(String[] args) {
        Account senderAccount = new Account("AC101", "Dhruv Trivedi", 8000);
        Account receiverAccount = new Account("AC102", "Ishita Joshi", 4000);

        try (AuditSession transactionAudit = new AuditSession("TXN_AUDIT_2026_01")) {
            System.out.println("\n--- Attempting Negative Deposit ---");
            try {
                senderAccount.deposit(-1500);
            } catch (InvalidAmountException invalidEx) {
                System.out.println("Caught Expected Error: " + invalidEx.getMessage());
            }

            System.out.println("\n--- Attempting Over-Withdrawal ---");
            try {
                senderAccount.withdraw(12000);
            } catch (InsufficientFundsException fundsEx) {
                System.out.println("Caught Expected Error: " + fundsEx.getMessage());
                System.out.println("Deficit Shortfall Amount: Rs. " + fundsEx.getShortfall());
            } catch (InvalidAmountException invalidEx) {
                System.out.println("Invalid Amount: " + invalidEx.getMessage());
            }

            System.out.println("\n--- Attempting Valid Transfer ---");
            try {
                senderAccount.transfer(receiverAccount, 3000);
            } catch (BankException bankEx) {
                System.out.println("Transfer failed: " + bankEx.getMessage());
            }

            System.out.println("\n--- Final Balances ---");
            System.out.println("Sender " + senderAccount.getAccountNumber() + " Balance: Rs. " + senderAccount.getBalance());
            System.out.println("Receiver " + receiverAccount.getAccountNumber() + " Balance: Rs. " + receiverAccount.getBalance());
        }
    }
}