import java.util.regex.Pattern;

class Account {
    private final String accountNumber;
    private final String ownerName;
    private final long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public long getBalance() {
        return balance;
    }
}

class Validator {
    private static final Pattern MOBILE_PATTERN = Pattern.compile("^[6-9]\\d{9}$");
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");
    private static final Pattern PAN_PATTERN = Pattern.compile("^[A-Z]{5}[0-9]{4}[A-Z]$");
    private static final Pattern IFSC_PATTERN = Pattern.compile("^[A-Z]{4}0[A-Z0-9]{6}$");

    public static boolean isValidMobile(String mobileNumber) {
        return mobileNumber != null && MOBILE_PATTERN.matcher(mobileNumber.trim()).matches();
    }

    public static boolean isValidEmail(String emailAddress) {
        return emailAddress != null && EMAIL_PATTERN.matcher(emailAddress.trim()).matches();
    }

    public static boolean isValidPan(String panNumber) {
        return panNumber != null && PAN_PATTERN.matcher(panNumber.trim()).matches();
    }

    public static boolean isValidIfsc(String ifscCode) {
        return ifscCode != null && IFSC_PATTERN.matcher(ifscCode.trim()).matches();
    }
}

enum TransactionType {
    DEPOSIT,
    WITHDRAW,
    TRANSFER
}

record Command(TransactionType type, String accountNumber, long amount) {}

class CommandParser {
    public static Command parse(String inputLine) {
        if (inputLine == null || inputLine.trim().isEmpty()) {
            throw new IllegalArgumentException("Input command line cannot be empty.");
        }
        String[] commandTokens = inputLine.trim().split("\\s+");
        if (commandTokens.length < 3) {
            throw new IllegalArgumentException("Invalid format. Expected: <TYPE> <ACC_NO> <AMOUNT>");
        }
        TransactionType transactionType = TransactionType.valueOf(commandTokens[0].toUpperCase());
        String targetAccount = commandTokens[1];
        long transactionAmount = Long.parseLong(commandTokens[2]);
        return new Command(transactionType, targetAccount, transactionAmount);
    }
}

class StatementFormatter {
    public static String buildStatement(Account targetAccount) {
        StringBuilder statementBuilder = new StringBuilder();
        statementBuilder.append("=========================================\n");
        statementBuilder.append("       MINIBANK ACCOUNT STATEMENT        \n");
        statementBuilder.append("=========================================\n");
        statementBuilder.append("Account Number  : ").append(targetAccount.getAccountNumber()).append("\n");
        statementBuilder.append("Account Holder  : ").append(targetAccount.getOwnerName()).append("\n");
        statementBuilder.append("Current Balance : Rs. ").append(targetAccount.getBalance()).append("\n");
        statementBuilder.append("Account Status  : Active\n");
        statementBuilder.append("Currency        : INR (Indian Rupees)\n");
        statementBuilder.append("=========================================");
        return statementBuilder.toString();
    }
}

public class Practical04_ValidationParsing {
    public static void main(String[] args) {
        System.out.println("--- Boundary Regex Validation Checks ---");
        System.out.println("Mobile '9825012345' : " + Validator.isValidMobile("9825012345"));
        System.out.println("Mobile '5412345678' : " + Validator.isValidMobile("5412345678"));
        System.out.println("Email 'user@bank.com' : " + Validator.isValidEmail("user@bank.com"));
        System.out.println("Email 'invalid#bank'  : " + Validator.isValidEmail("invalid#bank"));
        System.out.println("PAN 'ABCDE1234F'     : " + Validator.isValidPan("ABCDE1234F"));
        System.out.println("PAN '12345ABCDE'     : " + Validator.isValidPan("12345ABCDE"));
        System.out.println("IFSC 'SBIN0001234'   : " + Validator.isValidIfsc("SBIN0001234"));
        System.out.println("IFSC 'SBIN1234567'   : " + Validator.isValidIfsc("SBIN1234567"));

        System.out.println("\n--- Testing Command Parser ---");
        String sampleCommandLine = "DEPOSIT AC0001 5000";
        Command parsedCommand = CommandParser.parse(sampleCommandLine);
        System.out.println("Raw Input String   : " + sampleCommandLine);
        System.out.println("Parsed Action Type : " + parsedCommand.type());
        System.out.println("Target Account No  : " + parsedCommand.accountNumber());
        System.out.println("Transaction Amount : Rs. " + parsedCommand.amount());

        System.out.println("\n--- Testing Statement Formatter ---");
        Account customerAccount = new Account("AC0001", "Aarav Patel", 28500);
        String accountStatement = StatementFormatter.buildStatement(customerAccount);
        System.out.println(accountStatement);
    }
}