class UnsafeAccount {
    private long balance;

    public UnsafeAccount(long initialBalance) {
        this.balance = initialBalance;
    }

    public void deposit(long amount) {
        long currentVal = balance;
        try {
            Thread.sleep(1);
        } catch (InterruptedException ignored) {}
        balance = currentVal + amount;
    }

    public long getBalance() {
        return balance;
    }
}

class SafeAccount {
    private long balance;

    public SafeAccount(long initialBalance) {
        this.balance = initialBalance;
    }

    public synchronized void deposit(long amount) {
        balance += amount;
    }

    public synchronized void withdraw(long amount) {
        if (balance >= amount) {
            balance -= amount;
        }
    }

    public synchronized long getBalance() {
        return balance;
    }
}

class AccountWorker implements Runnable {
    private final SafeAccount safeAccount;
    private final int iterations;
    private final long depositAmount;

    public AccountWorker(SafeAccount safeAccount, int iterations, long depositAmount) {
        this.safeAccount = safeAccount;
        this.iterations = iterations;
        this.depositAmount = depositAmount;
    }

    @Override
    public void run() {
        System.out.println("Thread started: " + Thread.currentThread().getName());
        for (int cycle = 0; cycle < iterations; cycle++) {
            safeAccount.deposit(depositAmount);
        }
        System.out.println("Thread completed: " + Thread.currentThread().getName());
    }
}

public class Practical09_ThreadSafety {
    public static void main(String[] args) throws InterruptedException {
        int totalWorkers = 10;
        int operationsPerWorker = 1000;
        long amountPerDeposit = 10;
        long expectedIncrement = (long) totalWorkers * operationsPerWorker * amountPerDeposit;

        System.out.println("--- 1. Race Condition Demonstration (Unsynchronized) ---");
        UnsafeAccount hazardousAccount = new UnsafeAccount(0);
        Thread[] rawThreads = new Thread[totalWorkers];
        for (int i = 0; i < totalWorkers; i++) {
            rawThreads[i] = new Thread(() -> {
                for (int c = 0; c < 20; c++) {
                    hazardousAccount.deposit(10);
                }
            });
            rawThreads[i].start();
        }
        for (Thread t : rawThreads) {
            t.join();
        }
        System.out.println("Expected Unsafe Balance: Rs. 2000 | Actual Balance: Rs. " + hazardousAccount.getBalance() + " (Corrupted due to Race Condition)");

        System.out.println("\n--- 2. Thread-Safe Execution with Synchronization ---");
        SafeAccount securedAccount = new SafeAccount(0);
        Thread[] synchronizedThreads = new Thread[totalWorkers];

        for (int workerIndex = 0; workerIndex < totalWorkers; workerIndex++) {
            synchronizedThreads[workerIndex] = new Thread(
                new AccountWorker(securedAccount, operationsPerWorker, amountPerDeposit),
                "WorkerThread-" + (workerIndex + 1)
            );
            synchronizedThreads[workerIndex].start();
        }

        for (Thread workerThread : synchronizedThreads) {
            workerThread.join();
        }

        System.out.println("\n--- Thread Execution Results ---");
        System.out.println("Initial Balance    : Rs. 0");
        System.out.println("Expected Balance   : Rs. " + expectedIncrement);
        System.out.println("Actual Safe Total  : Rs. " + securedAccount.getBalance());
        System.out.println("Thread Synchronization Test: PASSED with zero race condition.");
    }
}