import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface Id {}

class Repository<T> {
    private final Map<String, T> entityStorage = new HashMap<>();

    public T save(T entity) {
        if (entity == null) {
            throw new IllegalArgumentException("Entity cannot be null.");
        }
        String extractedId = extractIdFromEntity(entity);
        entityStorage.put(extractedId, entity);
        return entity;
    }

    @SafeVarargs
    public final void saveAll(T... items) {
        for (T item : items) {
            save(item);
        }
    }

    public T findById(String identifier) {
        return entityStorage.get(identifier);
    }

    public ArrayList<T> findAll() {
        return new ArrayList<>(entityStorage.values());
    }

    public boolean delete(String identifier) {
        return entityStorage.remove(identifier) != null;
    }

    private String extractIdFromEntity(T entity) {
        Class<?> entityType = entity.getClass();
        for (Field currentField : entityType.getDeclaredFields()) {
            if (currentField.isAnnotationPresent(Id.class)) {
                currentField.setAccessible(true);
                try {
                    Object idValue = currentField.get(entity);
                    if (idValue != null) {
                        return idValue.toString();
                    }
                } catch (IllegalAccessException accessException) {
                    throw new RuntimeException("Failed to access @Id field", accessException);
                }
            }
        }
        throw new IllegalStateException("Entity of type " + entityType.getName() + " does not have an @Id annotated field.");
    }

    public static <N extends Number> double average(N[] numbersArray) {
        if (numbersArray == null || numbersArray.length == 0) {
            return 0.0;
        }
        double runningSum = 0.0;
        for (N singleNum : numbersArray) {
            runningSum += singleNum.doubleValue();
        }
        return runningSum / numbersArray.length;
    }
}

class Account {
    @Id
    private final String accountNumber;
    private final String holderName;
    private final long balance;

    public Account(String accountNumber, String holderName, long balance) {
        this.accountNumber = accountNumber;
        this.holderName = holderName;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getHolderName() {
        return holderName;
    }

    public long getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        return "Account{" + accountNumber + ", '" + holderName + "', Rs. " + balance + "}";
    }
}

public class Practical13_GenericRepository {
    public static void main(String[] args) {
        Repository<Account> accountRepository = new Repository<>();

        Account accountOne = new Account("AC701", "Pranav Trivedi", 45000);
        Account accountTwo = new Account("AC702", "Natasha Kapadia", 78000);
        Account accountThree = new Account("AC703", "Yashwant Rao", 32000);

        System.out.println("--- 1. Testing @SafeVarargs saveAll() with Reflective @Id Detection ---");
        accountRepository.saveAll(accountOne, accountTwo, accountThree);
        System.out.println("Total entities stored in generic repository: " + accountRepository.findAll().size());

        System.out.println("\n--- 2. Fetching Entity by ID (findById) ---");
        Account queriedAccount = accountRepository.findById("AC702");
        System.out.println("Queried AC702 Result: " + queriedAccount);

        System.out.println("\n--- 3. Enumerating All Records in Repository ---");
        for (Account acc : accountRepository.findAll()) {
            System.out.println("  Repository Item: " + acc);
        }

        System.out.println("\n--- 4. Testing Bounded Generic Method <N extends Number> average() ---");
        Long[] accountBalances = new Long[] {45000L, 78000L, 32000L};
        double meanBalance = Repository.average(accountBalances);
        System.out.printf("Average Account Balance (Long[]): Rs. %.2f%n", meanBalance);

        Double[] interestRates = new Double[] {4.0, 7.5, 6.25, 5.0};
        double meanRate = Repository.average(interestRates);
        System.out.printf("Average Interest Rate (Double[]): %.2f%%%n", meanRate);
    }
}