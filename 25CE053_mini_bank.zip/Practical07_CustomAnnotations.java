import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface Id {}

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface Positive {
    String message() default "must be > 0";
}

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface MaxLength {
    int value();
    String message() default "exceeds maximum allowed length";
}

class Account {
    @Id
    private String accountNumber;

    @MaxLength(12)
    private String ownerName;

    @Positive
    private long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public long getBalance() {
        return balance;
    }
}

class AnnotationValidator {
    public static String[] validate(Object targetEntity) {
        List<String> detectedErrors = new ArrayList<>();
        Class<?> entityClass = targetEntity.getClass();

        for (Field currentField : entityClass.getDeclaredFields()) {
            currentField.setAccessible(true);
            try {
                Object fieldValue = currentField.get(targetEntity);

                if (currentField.isAnnotationPresent(Positive.class)) {
                    Positive positiveAnnotation = currentField.getAnnotation(Positive.class);
                    if (fieldValue instanceof Number numericValue) {
                        if (numericValue.doubleValue() <= 0) {
                            detectedErrors.add("Field '" + currentField.getName() + "' (value: " + fieldValue + ") " + positiveAnnotation.message());
                        }
                    }
                }

                if (currentField.isAnnotationPresent(MaxLength.class)) {
                    MaxLength maxLengthAnnotation = currentField.getAnnotation(MaxLength.class);
                    if (fieldValue instanceof String textValue) {
                        if (textValue.length() > maxLengthAnnotation.value()) {
                            detectedErrors.add("Field '" + currentField.getName() + "' with length " + textValue.length() + " " + maxLengthAnnotation.message() + " of " + maxLengthAnnotation.value());
                        }
                    }
                }

            } catch (IllegalAccessException accessException) {
                detectedErrors.add("Unable to access field: " + currentField.getName());
            }
        }
        return detectedErrors.toArray(new String[0]);
    }
}

public class Practical07_CustomAnnotations {
    public static void main(String[] args) {
        System.out.println("--- Validating Valid Account ---");
        Account validAccount = new Account("AC001", "Aarav Shah", 12500);
        String[] validErrors = AnnotationValidator.validate(validAccount);
        if (validErrors.length == 0) {
            System.out.println("Validation Passed: Account AC001 has no constraint violations.");
        }

        System.out.println("\n--- Validating Defective Account (Negative Balance & Exceeded Name) ---");
        Account defectiveAccount = new Account("AC002", "Aaravindranath Mukhopadhyay", -4500);
        String[] detectedViolations = AnnotationValidator.validate(defectiveAccount);

        System.out.println("Total Violations Detected: " + detectedViolations.length);
        for (String currentViolation : detectedViolations) {
            System.out.println("  [VALIDATION ERROR] " + currentViolation);
        }
    }
}