import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class SynchronizedBuffer {
    private final List<String> queue = new ArrayList<>();
    private final int capacity = 3;

    public synchronized void produce(String transactionRecord) throws InterruptedException {
        while (queue.size() == capacity) {
            wait();
        }
        queue.add(transactionRecord);
        System.out.println("[Producer] Added transaction: " + transactionRecord);
        notifyAll();
    }

    public synchronized String consume() throws InterruptedException {
        while (queue.isEmpty()) {
            wait();
        }
        String transactionRecord = queue.remove(0);
        System.out.println("[Consumer] Processed transaction: " + transactionRecord);
        notifyAll();
        return transactionRecord;
    }
}

class BankAccount {
    private final String accountNumber;
    private long balance;

    public BankAccount(String accountNumber, long balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public synchronized void deposit(long amount) {
        balance += amount;
    }

    public synchronized void withdraw(long amount) {
        balance -= amount;
    }

    public synchronized long getBalance() {
        return balance;
    }

    public static void safeTransfer(BankAccount sourceAccount, BankAccount targetAccount, long amount) {
        BankAccount firstLock = sourceAccount.getAccountNumber().compareTo(targetAccount.getAccountNumber()) < 0 ? sourceAccount : targetAccount;
        BankAccount secondLock = firstLock == sourceAccount ? targetAccount : sourceAccount;

        synchronized (firstLock) {
            synchronized (secondLock) {
                sourceAccount.withdraw(amount);
                targetAccount.deposit(amount);
                System.out.println("Safe Transfer of Rs. " + amount + " from " + sourceAccount.getAccountNumber() + " to " + targetAccount.getAccountNumber() + " finished.");
            }
        }
    }
}

class TransactionProcessor {
    private final ExecutorService threadPoolExecutor;

    public TransactionProcessor(int poolSize) {
        this.threadPoolExecutor = Executors.newFixedThreadPool(poolSize);
    }

    public void submit(Runnable transactionTask) {
        threadPoolExecutor.execute(transactionTask);
    }

    public void stop() {
        threadPoolExecutor.shutdown();
        try {
            if (!threadPoolExecutor.awaitTermination(3, TimeUnit.SECONDS)) {
                threadPoolExecutor.shutdownNow();
            }
        } catch (InterruptedException interruptedEx) {
            threadPoolExecutor.shutdownNow();
        }
    }
}

public class Practical10_TransactionEngine {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("--- 1. Managed Thread Pool Processing ---");
        TransactionProcessor processor = new TransactionProcessor(4);
        BankAccount centralAccount = new BankAccount("AC_CENTRAL", 100000);

        for (int taskId = 1; taskId <= 8; taskId++) {
            final int currentId = taskId;
            processor.submit(() -> {
                if (currentId % 2 == 0) {
                    centralAccount.deposit(1500);
                    System.out.println("Pool Task " + currentId + " executed deposit of Rs. 1500 by " + Thread.currentThread().getName());
                } else {
                    centralAccount.withdraw(1000);
                    System.out.println("Pool Task " + currentId + " executed withdraw of Rs. 1000 by " + Thread.currentThread().getName());
                }
            });
        }
        processor.stop();
        System.out.println("All thread pool transactions completed. Central Balance: Rs. " + centralAccount.getBalance());

        System.out.println("\n--- 2. Producer-Consumer Coordination (wait/notify) ---");
        SynchronizedBuffer transactionBuffer = new SynchronizedBuffer();
        Thread producerThread = new Thread(() -> {
            try {
                for (int i = 1; i <= 4; i++) {
                    transactionBuffer.produce("TXN_00" + i);
                    Thread.sleep(50);
                }
            } catch (InterruptedException ignored) {}
        });

        Thread consumerThread = new Thread(() -> {
            try {
                for (int i = 1; i <= 4; i++) {
                    transactionBuffer.consume();
                    Thread.sleep(80);
                }
            } catch (InterruptedException ignored) {}
        });

        producerThread.start();
        consumerThread.start();
        producerThread.join();
        consumerThread.join();

        System.out.println("\n--- 3. Deadlock Avoidance via Consistent Lock Ordering ---");
        BankAccount accountX = new BankAccount("AC101", 50000);
        BankAccount accountY = new BankAccount("AC202", 50000);

        Thread transferOne = new Thread(() -> BankAccount.safeTransfer(accountX, accountY, 5000));
        Thread transferTwo = new Thread(() -> BankAccount.safeTransfer(accountY, accountX, 3000));

        transferOne.start();
        transferTwo.start();
        transferOne.join();
        transferTwo.join();

        System.out.println("Account X Balance: Rs. " + accountX.getBalance());
        System.out.println("Account Y Balance: Rs. " + accountY.getBalance());
        System.out.println("Consistent Lock Ordering prevented deadlock successfully.");
    }
}