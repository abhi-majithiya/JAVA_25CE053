class Customer {
    private static long customerCounter = 100;
    private final String customerId;
    private String name;
    private String email;
    private String mobile;

    public Customer(String name, String email, String mobile) {
        this.customerId = generateCustomerId();
        this.name = name;
        this.email = email;
        this.mobile = mobile;
    }

    private static String generateCustomerId() {
        customerCounter++;
        return "CUST" + customerCounter;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getMobile() {
        return mobile;
    }
}

class Account {
    private static long accountCounter = 0;
    private final String accountNumber;
    private String ownerName;
    private long balance;
    private boolean active;

    public Account(String ownerName, long balance) {
        accountCounter++;
        this.accountNumber = String.format("AC%04d", accountCounter);
        this.ownerName = ownerName;
        this.balance = balance;
        this.active = true;
    }

    public Account(String ownerName) {
        this(ownerName, 0);
    }

    public void deposit(long amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited Rs. " + amount + " into " + accountNumber + ". Current balance: Rs. " + balance);
        }
    }

    public boolean withdraw(long amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            System.out.println("Withdrew Rs. " + amount + " from " + accountNumber + ". Current balance: Rs. " + balance);
            return true;
        } else {
            System.out.println("Withdrawal of Rs. " + amount + " failed for " + accountNumber + ". Insufficient balance: Rs. " + balance);
            return false;
        }
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public long getBalance() {
        return balance;
    }

    public boolean isActive() {
        return active;
    }
}

public class Practical02_CustomerAccount {
    public static void main(String[] args) {
        Customer primaryCustomer = new Customer("Aarav Patel", "aarav.patel@email.com", "9876543210");
        System.out.println("Created Customer: " + primaryCustomer.getCustomerId() + " | " + primaryCustomer.getName() + " | " + primaryCustomer.getEmail());

        Account[] customerAccounts = new Account[3];
        customerAccounts[0] = new Account("Aarav Patel", 15000);
        customerAccounts[1] = new Account("Diya Sharma", 25000);
        customerAccounts[2] = new Account("Rohan Mehta");

        System.out.println("\n--- Initial Account States ---");
        for (Account currentAccount : customerAccounts) {
            System.out.println("Account: " + currentAccount.getAccountNumber() + " | Owner: " + currentAccount.getOwnerName() + " | Balance: Rs. " + currentAccount.getBalance());
        }

        System.out.println("\n--- Performing Transactions ---");
        customerAccounts[0].deposit(5000);
        customerAccounts[0].withdraw(3000);
        customerAccounts[1].withdraw(30000);
        customerAccounts[2].deposit(12000);
        customerAccounts[2].withdraw(4500);

        System.out.println("\n--- Final Account Balances ---");
        for (Account currentAccount : customerAccounts) {
            System.out.println("Account: " + currentAccount.getAccountNumber() + " | Owner: " + currentAccount.getOwnerName() + " | Final Balance: Rs. " + currentAccount.getBalance());
        }
    }
}