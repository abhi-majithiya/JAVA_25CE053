import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

class Account implements Comparable<Account> {
    private final String accountNumber;
    private final String ownerName;
    private long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public long getBalance() {
        return balance;
    }

    @Override
    public int compareTo(Account otherAccount) {
        return this.accountNumber.compareTo(otherAccount.accountNumber);
    }

    @Override
    public String toString() {
        return String.format("[%s] %-14s | Balance: Rs. %d", accountNumber, ownerName, balance);
    }
}

class AccountStore {
    private final Map<String, Account> accountsMap = new HashMap<>();
    private final List<String> transactionHistory = new ArrayList<>();

    public void add(Account newAccount) {
        accountsMap.put(newAccount.getAccountNumber(), newAccount);
        transactionHistory.add("Registered account " + newAccount.getAccountNumber() + " for " + newAccount.getOwnerName());
    }

    public Account get(String accountNumber) {
        return accountsMap.get(accountNumber);
    }

    public List<Account> getAll() {
        return new ArrayList<>(accountsMap.values());
    }

    public List<String> getTransactionHistory() {
        return Collections.unmodifiableList(transactionHistory);
    }

    public List<Account> sortedByBalance() {
        List<Account> sortedList = new ArrayList<>(accountsMap.values());
        sortedList.sort(Comparator.comparingLong(Account::getBalance).reversed());
        return sortedList;
    }
}

public class Practical12_CollectionsStore {
    public static void main(String[] args) {
        AccountStore centralStore = new AccountStore();

        centralStore.add(new Account("AC104", "Ananya Roy", 18000));
        centralStore.add(new Account("AC101", "Kunal Singhania", 95000));
        centralStore.add(new Account("AC105", "Shruti Verma", 42000));
        centralStore.add(new Account("AC102", "Devendra Joshi", 125000));
        centralStore.add(new Account("AC103", "Nidhi Trivedi", 64000));

        System.out.println("--- 1. Natural Ordering (Comparable by Account Number) ---");
        List<Account> naturalOrderedList = centralStore.getAll();
        Collections.sort(naturalOrderedList);
        for (Account acc : naturalOrderedList) {
            System.out.println(acc);
        }

        System.out.println("\n--- 2. Custom Ordering (Comparator: Highest Balance First) ---");
        List<Account> balanceOrderedList = centralStore.sortedByBalance();
        for (Account acc : balanceOrderedList) {
            System.out.println(acc);
        }

        System.out.println("\n--- 3. Direct Key Lookup via HashMap ---");
        String lookupId = "AC102";
        Account fetchedAccount = centralStore.get(lookupId);
        System.out.println("Fetched details for key '" + lookupId + "': " + fetchedAccount);

        System.out.println("\n--- 4. ConcurrentHashMap Thread-Safe Store ---");
        Map<String, Long> concurrentBalances = new ConcurrentHashMap<>();
        concurrentBalances.put("AC101", 95000L);
        concurrentBalances.put("AC102", 125000L);
        concurrentBalances.computeIfPresent("AC101", (key, val) -> val + 5000L);
        System.out.println("ConcurrentHashMap AC101 Updated Balance: Rs. " + concurrentBalances.get("AC101"));

        System.out.println("\n--- 5. Audit History Log (ArrayList) ---");
        for (String record : centralStore.getTransactionHistory()) {
            System.out.println("  Log -> " + record);
        }
    }
}