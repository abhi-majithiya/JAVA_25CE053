abstract class Account {
    private final String accountNumber;
    private final String ownerName;
    protected long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public abstract double interestRate();
    public abstract boolean canWithdraw(long amount);

    public void deposit(long amount) {
        if (amount > 0) {
            balance += amount;
        }
    }

    public boolean withdraw(long amount) {
        if (amount > 0 && canWithdraw(amount)) {
            balance -= amount;
            return true;
        }
        return false;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public long getBalance() {
        return balance;
    }
}

class SavingsAccount extends Account {
    private final long minBalance;

    public SavingsAccount(String accountNumber, String ownerName, long balance, long minBalance) {
        super(accountNumber, ownerName, balance);
        this.minBalance = minBalance;
    }

    @Override
    public double interestRate() {
        return 4.0;
    }

    @Override
    public boolean canWithdraw(long amount) {
        return (balance - amount) >= minBalance;
    }

    public long getMinBalance() {
        return minBalance;
    }
}

class CurrentAccount extends Account {
    private final long overdraftLimit;

    public CurrentAccount(String accountNumber, String ownerName, long balance, long overdraftLimit) {
        super(accountNumber, ownerName, balance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public double interestRate() {
        return 0.0;
    }

    @Override
    public boolean canWithdraw(long amount) {
        return (balance - amount) >= -overdraftLimit;
    }

    public long getOverdraftLimit() {
        return overdraftLimit;
    }
}

class FixedDepositAccount extends Account {
    public FixedDepositAccount(String accountNumber, String ownerName, long balance) {
        super(accountNumber, ownerName, balance);
    }

    @Override
    public double interestRate() {
        return 7.0;
    }

    @Override
    public boolean canWithdraw(long amount) {
        return false;
    }
}

public class Practical05_PolymorphicAccounts {
    public static void main(String[] args) {
        Account[] bankingAccounts = new Account[] {
            new SavingsAccount("SB101", "Kiran Varma", 20000, 2000),
            new CurrentAccount("CA202", "Apex Traders", 50000, 30000),
            new FixedDepositAccount("FD303", "Meera Desai", 100000)
        };

        System.out.println("--- Polymorphic Account Evaluation ---");
        for (Account currentAccount : bankingAccounts) {
            System.out.printf("Account: %-6s | Type: %-20s | Balance: Rs. %-8d | Interest Rate: %.1f%%%n",
                currentAccount.getAccountNumber(),
                currentAccount.getClass().getSimpleName(),
                currentAccount.getBalance(),
                currentAccount.interestRate());

            if (currentAccount instanceof CurrentAccount currentAcc) {
                System.out.println("  -> Pattern Match Note: CurrentAccount has Overdraft Protection up to Rs. " + currentAcc.getOverdraftLimit());
            } else if (currentAccount instanceof SavingsAccount savingsAcc) {
                System.out.println("  -> Pattern Match Note: SavingsAccount mandatory minimum balance is Rs. " + savingsAcc.getMinBalance());
            } else if (currentAccount instanceof FixedDepositAccount) {
                System.out.println("  -> Pattern Match Note: FixedDepositAccount is locked until maturity (canWithdraw = false).");
            }
        }

        System.out.println("\n--- Testing Withdrawal Polymorphism ---");
        System.out.println("SB101 attempting withdraw 19000 (leaves 1000, min 2000): " + bankingAccounts[0].withdraw(19000));
        System.out.println("SB101 attempting withdraw 15000 (leaves 5000, min 2000): " + bankingAccounts[0].withdraw(15000));
        System.out.println("CA202 attempting withdraw 70000 (leaves -20000, limit 30000): " + bankingAccounts[1].withdraw(70000));
        System.out.println("FD303 attempting withdraw 5000: " + bankingAccounts[2].withdraw(5000));
    }
}