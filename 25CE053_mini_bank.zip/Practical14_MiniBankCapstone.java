import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.*;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface Id {}

class BankException extends Exception {
    public BankException(String msg) {
        super(msg);
    }
}

class InsufficientFundsException extends BankException {
    private final long shortfall;
    public InsufficientFundsException(String msg, long shortfall) {
        super(msg);
        this.shortfall = shortfall;
    }
    public long getShortfall() {
        return shortfall;
    }
}

class AccountNotFoundException extends BankException {
    public AccountNotFoundException(String msg) {
        super(msg);
    }
}

class InvalidAmountException extends BankException {
    public InvalidAmountException(String msg) {
        super(msg);
    }
}

class Account implements Serializable {
    private static final long serialVersionUID = 202614L;
    @Id
    private final String accountNumber;
    private final String ownerName;
    private long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public synchronized void deposit(long amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Deposit must be positive: Rs. " + amount);
        }
        balance += amount;
    }

    public synchronized void withdraw(long amount) throws InsufficientFundsException, InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal must be positive: Rs. " + amount);
        }
        if (amount > balance) {
            throw new InsufficientFundsException("Insufficient funds on " + accountNumber, amount - balance);
        }
        balance -= amount;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public synchronized long getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        return String.format("[%s] %-16s | Balance: Rs. %d", accountNumber, ownerName, getBalance());
    }
}

class Repository<T> {
    private final Map<String, T> storage = new ConcurrentHashMap<>();

    public void save(T entity) {
        for (Field f : entity.getClass().getDeclaredFields()) {
            if (f.isAnnotationPresent(Id.class)) {
                f.setAccessible(true);
                try {
                    String id = f.get(entity).toString();
                    storage.put(id, entity);
                    return;
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        }
    }

    public T findById(String id) {
        return storage.get(id);
    }

    public List<T> findAll() {
        return new ArrayList<>(storage.values());
    }
}

class BankService {
    private final Repository<Account> repository = new Repository<>();
    private final Path storagePath = Paths.get("minibank_accounts.dat");

    public BankService() {
        loadAccounts();
    }

    public Account openAccount(String accNo, String owner, long initialDeposit) throws InvalidAmountException {
        if (initialDeposit < 0) {
            throw new InvalidAmountException("Initial deposit cannot be negative.");
        }
        Account newAcc = new Account(accNo, owner, initialDeposit);
        repository.save(newAcc);
        return newAcc;
    }

    public void deposit(String accNo, long amount) throws BankException {
        Account acc = repository.findById(accNo);
        if (acc == null) throw new AccountNotFoundException("Account " + accNo + " not found.");
        acc.deposit(amount);
    }

    public void withdraw(String accNo, long amount) throws BankException {
        Account acc = repository.findById(accNo);
        if (acc == null) throw new AccountNotFoundException("Account " + accNo + " not found.");
        acc.withdraw(amount);
    }

    public void transfer(String fromAccNo, String toAccNo, long amount) throws BankException {
        Account from = repository.findById(fromAccNo);
        Account to = repository.findById(toAccNo);
        if (from == null) throw new AccountNotFoundException("Sender account " + fromAccNo + " not found.");
        if (to == null) throw new AccountNotFoundException("Beneficiary account " + toAccNo + " not found.");
        from.withdraw(amount);
        to.deposit(amount);
    }

    public String statement(String accNo) throws BankException {
        Account acc = repository.findById(accNo);
        if (acc == null) throw new AccountNotFoundException("Account " + accNo + " not found.");
        return "Statement: " + acc.getAccountNumber() + " | Owner: " + acc.getOwnerName() + " | Balance: Rs. " + acc.getBalance();
    }

    public List<Account> listAccounts() {
        return repository.findAll();
    }

    public void saveAccounts() {
        try (ObjectOutputStream oos = new ObjectOutputStream(Files.newOutputStream(storagePath))) {
            oos.writeObject(new ArrayList<>(repository.findAll()));
        } catch (Exception ignored) {}
    }

    @SuppressWarnings("unchecked")
    private void loadAccounts() {
        if (!Files.exists(storagePath)) {
            try {
                openAccount("AC001", "Aarav Patel", 25000);
                openAccount("AC002", "Diya Sharma", 40000);
                openAccount("AC003", "Rohan Mehta", 15000);
            } catch (Exception ignored) {}
            return;
        }
        try (ObjectInputStream ois = new ObjectInputStream(Files.newInputStream(storagePath))) {
            List<Account> list = (List<Account>) ois.readObject();
            for (Account a : list) repository.save(a);
        } catch (Exception ex) {
            try {
                openAccount("AC001", "Aarav Patel", 25000);
                openAccount("AC002", "Diya Sharma", 40000);
                openAccount("AC003", "Rohan Mehta", 15000);
            } catch (Exception ignored) {}
        }
    }
}

public class Practical14_MiniBankCapstone {
    public static void main(String[] args) throws Exception {
        System.out.println("=================================================");
        System.out.println("      MINIBANK CAPSTONE SUITE - MILESTONE 3      ");
        System.out.println("=================================================");

        BankService bankService = new BankService();

        System.out.println("\n--- Current Registered Accounts ---");
        for (Account a : bankService.listAccounts()) {
            System.out.println(a);
        }

        System.out.println("\n--- 1. Testing Core Operations ---");
        try {
            bankService.deposit("AC001", 5000);
            System.out.println("Deposit of Rs. 5000 to AC001 completed.");
            bankService.withdraw("AC002", 10000);
            System.out.println("Withdrawal of Rs. 10000 from AC002 completed.");
            bankService.transfer("AC001", "AC003", 4000);
            System.out.println("Transfer of Rs. 4000 from AC001 to AC003 completed.");
        } catch (BankException ex) {
            System.out.println("Transaction Error: " + ex.getMessage());
        }

        System.out.println("\n--- 2. Testing Exception Scenarios ---");
        try {
            bankService.withdraw("AC003", 50000);
        } catch (InsufficientFundsException ex) {
            System.out.println("Caught InsufficientFundsException: Shortfall of Rs. " + ex.getShortfall());
        } catch (BankException ex) {
            System.out.println("Caught BankException: " + ex.getMessage());
        }

        System.out.println("\n--- 3. Testing Concurrent Batch Processing ---");
        ExecutorService pool = Executors.newFixedThreadPool(4);
        for (int i = 0; i < 10; i++) {
            pool.execute(() -> {
                try {
                    bankService.deposit("AC001", 100);
                } catch (Exception ignored) {}
            });
        }
        pool.shutdown();
        pool.awaitTermination(2, TimeUnit.SECONDS);
        System.out.println("Concurrent batch transactions finished successfully.");

        System.out.println("\n--- 4. Account Statements ---");
        for (Account a : bankService.listAccounts()) {
            System.out.println(bankService.statement(a.getAccountNumber()));
        }

        bankService.saveAccounts();
        System.out.println("\nAll state persisted. MiniBank Capstone executed successfully.");
    }
}