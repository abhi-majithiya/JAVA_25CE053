import java.io.*;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Pattern;

class MiniBankApp {
    public static void main(String[] args) {
        BankInfo bankInfo = new BankInfo("CHARUSAT Apex Bank", "Changa Main Branch");
        System.out.println("=================================================");
        System.out.println("       " + bankInfo.name() + " - " + bankInfo.branch());
        System.out.println("              Student Roll: 25CE053");
        System.out.println("=================================================");

        BankService bankService = new BankService();

        System.out.println("\n--- Initial Account Inventory ---");
        for (Account account : bankService.listAccounts()) {
            System.out.println(account);
        }

        System.out.println("\n--- Executing Practical Demonstrations ---");
        try {
            System.out.println("1. Deposit Rs. 10000 into AC1001...");
            bankService.deposit("AC1001", 10000);
            System.out.println("   AC1001 Balance: Rs. " + bankService.listAccounts().get(0).getBalance());

            System.out.println("2. Withdraw Rs. 15000 from AC1002 (Current Account Overdraft)...");
            bankService.withdraw("AC1002", 15000);

            System.out.println("3. Transfer Rs. 5000 from AC1001 to AC1003 (Deadlock-Safe)...");
            bankService.transfer("AC1001", "AC1003", 5000);

            System.out.println("4. Generating Account Statement for AC1001:");
            System.out.println(bankService.statement("AC1001"));

            System.out.println("\n5. Exception Handling Test (Attempt Overdraft beyond limit):");
            try {
                bankService.withdraw("AC1003", 80000);
            } catch (InsufficientFundsException fundsEx) {
                System.out.println("   [CAUGHT EXPECTED EXCEPTION] " + fundsEx.getMessage());
                System.out.println("   Deficit Shortfall: Rs. " + fundsEx.getShortfall());
            }

            System.out.println("\n6. Multi-Threaded Batch Transaction Execution (ExecutorService):");
            bankService.runConcurrentBatch();

            System.out.println("\n--- Final Updated Account Summary ---");
            for (Account account : bankService.listAccounts()) {
                System.out.println(account);
            }

            System.out.println("\nMiniBank Project Work execution completed successfully.");
        } catch (Exception generalEx) {
            generalEx.printStackTrace();
        }
    }
}

record BankInfo(String name, String branch) {}

enum MenuOption {
    OPEN_ACCOUNT,
    DEPOSIT,
    WITHDRAW,
    TRANSFER,
    ACCOUNT_STATEMENT,
    LIST_ACCOUNTS,
    BATCH_PROCESSING,
    EXIT
}

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface Id {}

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface Positive {
    String message() default "must be positive";
}

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface MaxLength {
    int value();
}

class BankException extends Exception {
    public BankException(String message) {
        super(message);
    }
}

class InsufficientFundsException extends BankException {
    private final long shortfall;

    public InsufficientFundsException(String message, long shortfall) {
        super(message);
        this.shortfall = shortfall;
    }

    public long getShortfall() {
        return shortfall;
    }
}

class AccountNotFoundException extends BankException {
    public AccountNotFoundException(String message) {
        super(message);
    }
}

class InvalidAmountException extends BankException {
    public InvalidAmountException(String message) {
        super(message);
    }
}

class Customer implements Serializable, Cloneable {
    private static final long serialVersionUID = 202601L;
    private final String customerId;
    private String name;
    private String email;
    private String mobile;

    public Customer(String customerId, String name, String email, String mobile) {
        this.customerId = customerId;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getMobile() {
        return mobile;
    }

    @Override
    public Customer clone() {
        try {
            return (Customer) super.clone();
        } catch (CloneNotSupportedException e) {
            return new Customer(customerId, name, email, mobile);
        }
    }
}

abstract class Account implements Serializable, Comparable<Account> {
    private static final long serialVersionUID = 202602L;

    @Id
    protected final String accountNumber;

    @MaxLength(20)
    protected final String ownerName;

    @Positive
    protected long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public abstract double interestRate();
    public abstract boolean canWithdraw(long amount);

    public synchronized void deposit(long amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Deposit amount must be positive: Rs. " + amount);
        }
        balance += amount;
    }

    public synchronized void withdraw(long amount) throws InsufficientFundsException, InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal amount must be positive: Rs. " + amount);
        }
        if (!canWithdraw(amount)) {
            long deficit = amount - balance;
            throw new InsufficientFundsException("Insufficient funds on " + accountNumber + " for withdrawal of Rs. " + amount, deficit);
        }
        balance -= amount;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public synchronized long getBalance() {
        return balance;
    }

    @Override
    public int compareTo(Account otherAccount) {
        return this.accountNumber.compareTo(otherAccount.accountNumber);
    }

    @Override
    public boolean equals(Object otherObject) {
        if (this == otherObject) return true;
        if (otherObject == null || getClass() != otherObject.getClass()) return false;
        Account otherAccount = (Account) otherObject;
        return Objects.equals(accountNumber, otherAccount.accountNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountNumber);
    }

    @Override
    public String toString() {
        return String.format("[%s] %-16s | Type: %-14s | Balance: Rs. %d",
            accountNumber, ownerName, getClass().getSimpleName(), getBalance());
    }
}

class SavingsAccount extends Account {
    private static final long serialVersionUID = 202603L;
    private final long minimumBalance;

    public SavingsAccount(String accountNumber, String ownerName, long balance, long minimumBalance) {
        super(accountNumber, ownerName, balance);
        this.minimumBalance = minimumBalance;
    }

    @Override
    public double interestRate() {
        return 4.0;
    }

    @Override
    public boolean canWithdraw(long amount) {
        return (balance - amount) >= minimumBalance;
    }
}

class CurrentAccount extends Account {
    private static final long serialVersionUID = 202604L;
    private final long overdraftLimit;

    public CurrentAccount(String accountNumber, String ownerName, long balance, long overdraftLimit) {
        super(accountNumber, ownerName, balance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public double interestRate() {
        return 0.0;
    }

    @Override
    public boolean canWithdraw(long amount) {
        return (balance - amount) >= -overdraftLimit;
    }
}

class Validator {
    private static final Pattern MOBILE_PATTERN = Pattern.compile("^[6-9]\\d{9}$");
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");
    private static final Pattern PAN_PATTERN = Pattern.compile("^[A-Z]{5}[0-9]{4}[A-Z]$");
    private static final Pattern IFSC_PATTERN = Pattern.compile("^[A-Z]{4}0[A-Z0-9]{6}$");

    public static boolean isValidMobile(String mobileNumber) {
        return mobileNumber != null && MOBILE_PATTERN.matcher(mobileNumber.trim()).matches();
    }

    public static boolean isValidEmail(String emailAddress) {
        return emailAddress != null && EMAIL_PATTERN.matcher(emailAddress.trim()).matches();
    }

    public static boolean isValidPan(String panNumber) {
        return panNumber != null && PAN_PATTERN.matcher(panNumber.trim()).matches();
    }

    public static boolean isValidIfsc(String ifscCode) {
        return ifscCode != null && IFSC_PATTERN.matcher(ifscCode.trim()).matches();
    }
}

class Repository<T> {
    private final Map<String, T> storageMap = new ConcurrentHashMap<>();

    public void save(T entity) {
        for (Field currentField : entity.getClass().getSuperclass().getDeclaredFields()) {
            if (currentField.isAnnotationPresent(Id.class)) {
                currentField.setAccessible(true);
                try {
                    String identifier = currentField.get(entity).toString();
                    storageMap.put(identifier, entity);
                    return;
                } catch (Exception accessEx) {
                    throw new RuntimeException(accessEx);
                }
            }
        }
        for (Field currentField : entity.getClass().getDeclaredFields()) {
            if (currentField.isAnnotationPresent(Id.class)) {
                currentField.setAccessible(true);
                try {
                    String identifier = currentField.get(entity).toString();
                    storageMap.put(identifier, entity);
                    return;
                } catch (Exception accessEx) {
                    throw new RuntimeException(accessEx);
                }
            }
        }
    }

    public T findById(String identifier) {
        return storageMap.get(identifier);
    }

    public List<T> findAll() {
        return new ArrayList<>(storageMap.values());
    }
}

class BankService {
    private final Repository<Account> repository = new Repository<>();
    private final Path backupFilePath = Paths.get("minibank_accounts.dat");

    public BankService() {
        seedAccounts();
    }

    private void seedAccounts() {
        repository.save(new SavingsAccount("AC1001", "Aarav Patel", 45000, 2000));
        repository.save(new CurrentAccount("AC1002", "Apex Enterprises", 85000, 25000));
        repository.save(new SavingsAccount("AC1003", "Diya Sharma", 32000, 2000));
    }

    public Account openSavingsAccount(String accNo, String owner, long balance, long minBalance) throws InvalidAmountException {
        if (balance < minBalance) {
            throw new InvalidAmountException("Initial deposit cannot be below minimum balance: Rs. " + minBalance);
        }
        SavingsAccount newAccount = new SavingsAccount(accNo, owner, balance, minBalance);
        repository.save(newAccount);
        return newAccount;
    }

    public void deposit(String accNo, long amount) throws BankException {
        Account targetAccount = repository.findById(accNo);
        if (targetAccount == null) throw new AccountNotFoundException("Account " + accNo + " not found.");
        targetAccount.deposit(amount);
    }

    public void withdraw(String accNo, long amount) throws BankException {
        Account targetAccount = repository.findById(accNo);
        if (targetAccount == null) throw new AccountNotFoundException("Account " + accNo + " not found.");
        targetAccount.withdraw(amount);
    }

    public void transfer(String fromAcc, String toAcc, long amount) throws BankException {
        Account sender = repository.findById(fromAcc);
        Account receiver = repository.findById(toAcc);
        if (sender == null) throw new AccountNotFoundException("Sender " + fromAcc + " not found.");
        if (receiver == null) throw new AccountNotFoundException("Receiver " + toAcc + " not found.");

        Account firstLock = sender.getAccountNumber().compareTo(receiver.getAccountNumber()) < 0 ? sender : receiver;
        Account secondLock = firstLock == sender ? receiver : sender;

        synchronized (firstLock) {
            synchronized (secondLock) {
                sender.withdraw(amount);
                receiver.deposit(amount);
            }
        }
    }

    public String statement(String accNo) throws BankException {
        Account acc = repository.findById(accNo);
        if (acc == null) throw new AccountNotFoundException("Account " + accNo + " not found.");
        StringBuilder sb = new StringBuilder();
        sb.append("=========================================\n");
        sb.append("           MINIBANK STATEMENT            \n");
        sb.append("=========================================\n");
        sb.append("Account Number  : ").append(acc.getAccountNumber()).append("\n");
        sb.append("Account Holder  : ").append(acc.getOwnerName()).append("\n");
        sb.append("Account Class   : ").append(acc.getClass().getSimpleName()).append("\n");
        sb.append("Current Balance : Rs. ").append(acc.getBalance()).append("\n");
        sb.append("Annual Interest : ").append(acc.interestRate()).append("%\n");
        sb.append("=========================================");
        return sb.toString();
    }

    public List<Account> listAccounts() {
        List<Account> allAccounts = repository.findAll();
        Collections.sort(allAccounts);
        return allAccounts;
    }

    public void runConcurrentBatch() throws InterruptedException {
        ExecutorService threadPool = Executors.newFixedThreadPool(4);
        for (int i = 0; i < 8; i++) {
            final int txnId = i + 1;
            threadPool.execute(() -> {
                try {
                    deposit("AC1001", 500);
                    System.out.println("Batch Task #" + txnId + " deposited Rs. 500 into AC1001 via " + Thread.currentThread().getName());
                } catch (Exception ignored) {}
            });
        }
        threadPool.shutdown();
        threadPool.awaitTermination(3, TimeUnit.SECONDS);
    }
}
